from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
import os

def ordenarFiltar():
    ordenar = request.form.get('ordem')
    filtrar = request.form['filtro']


print(filtrar)